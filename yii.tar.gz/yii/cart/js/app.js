
$(document).bind("pageinit", function( event, data ){
    $("#cmbOcupado").change( function(){
		$.ajax({
			  type: 'GET',
			  url: "?r=movil/ocuparMesa",
			  data: { mesaId: $("#hidMesaId").val() },
			  success: function(data){
				  if (data==""){
					  if ($("#cmbOcupado").val()=="off"){
						$("#btnAgregar").addClass("ui-disabled");
						$("#txtCantPersona").addClass("ui-disabled");
					  }
					else{ 
						$("#btnAgregar").removeClass("ui-disabled");
						$("#txtCantPersona").removeClass("ui-disabled");
					}
				  } else {
					  $("#btnAgregar").removeClass("ui-disabled");
					  $("#txtCantPersona").removeClass("ui-disabled");
					  alert(data);
				  }
			  }
		});
	});
    $("#txtCantPersona").blur(function () {
    	$.ajax({
			  type: 'GET',
			  url: "?r=movil/ponerCantidadPersonas",
			  data: { pedidoId: $("#hidPedidoId").val(), cantPersona: $("#txtCantPersona").val() },
			  success: function(data){
				  
			  }
		});
     });
    $("#cmbCantidad").change(function() {
 	   $("#txtCantidad").val($("#cmbCantidad").val());      
    });
    $("#txtCantidad").blur(function () {
 	   $("#cmbCantidad option[value=" + $("#txtCantidad").val() + "]").attr("selected",true);
 	   $("#cmbCantidad").selectmenu("refresh", true);
    });
    $("#txtPagado").blur(function () {
    	var vuelto = $("#txtPagado").val() - $("#txtImporte").val();
    	if (vuelto<0){
    		alert("Lo consumido es menor que lo pagado");
    		$("#btnPagar").addClass("ui-disabled");
    	}
    	else 
    		$("#btnPagar").removeClass("ui-disabled");
    	$("#txtVuelto").val(vuelto) ;
    });
    $(".hreFoto").click(function(){
    	$("#fotoPlato").attr("src","img/"+this.title);
    });
});