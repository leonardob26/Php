$(function() {
	
	/*var ws = $.websocket("ws://192.168.147.28:12345/echo/", {
        events:{
            message: function(e) {
                if (e.data=="change" && change)  
                	location.href='?r=pedidos/pedidos' + controller;
                else if(print){                	
               	 	$("#hidPedidoId").val(e.data.substring(5));
               	 	imprimir();
                }
            }
   	},
   });*/
   
   $("#txtEfectivoMN").blur(function() {
	  darVuelto();
   });
   $("#txtEfectivoCuc").blur(function() {
		  darVuelto();
   });
   $("#btnEliminarPedido").submit(function(event){
	   var conf = confirm("¿Desea eliminar el pedido?");
	   if (conf!=true)
		   event.preventDefault();
   });

   $("#btnCerrarPedido").click(function(event){
	   var conf = confirm("¿Desea cerrar el pedido?");
	   if (conf!=true)
		   event.preventDefault();
	   else{
		   /*var conf1 = confirm("¿Imprimir el comprobante?");
		   if (conf1==true){
			   imprimir()
		       var t=setTimeout(function(){ alert("Algo")},10000);
		       event.preventDefault();
		   }*/
	   }
   });
   function darVuelto(){
	   var importe =0;
		 var cambio = 0;
		 var efectivomn = 0;
		 var efectivocuc = 0;
		 var efectivo = 0;
		 
		 if ($("#txtEfectivoMN").val()!="")
			 efectivomn = parseFloat($("#txtEfectivoMN").val());
		 if ($("#txtEfectivoCuc").val()!="")
			 efectivocuc = parseFloat($("#txtEfectivoCuc").val());
		 if ($("#hidCambio").val()!="")
			 cambio = parseFloat($("#hidCambio").val());
		 if ($("#hidImporte").val()!="")
		     importe = parseFloat($("#hidImporte").val());
		     
		 efectivo = efectivomn + efectivocuc*cambio;
		 
		 $("#txtVueltoMN").val(efectivo-importe);
		 $("#txtVueltoCuc").val(((efectivo-importe)/cambio).toFixed(2));   
		 if((efectivo-importe)<0){
			 $("#txtVueltoCuc").css("background","red");
			 $("#txtVueltoMN").css("background","red");
		 } else{
			 $("#txtVueltoCuc").css("background","");
			 $("#txtVueltoMN").css("background","");
		 }
   }

   $("#btnPrint").click(function(event){
	   imprimir();
	});
   function imprimir(){
	   $.ajax({ type: 'GET', url: "?r=pedidos/getDataPrint", data: {'pedidoId': $("#hidPedidoId").val()}, 
			success: function(data){
				if (data!=""){
					var result = jQuery.parseJSON(data);
					//[0]  $mesa, [1] $cantPersona, [2] $importeTotal, [3] Arreglo de detalles 
			    	var platos = result[3];
			    	
				    var html = '<html><head></head>';
				    html = html + '<body style="margin: 0 auto; width: 330px;"><div align="center" style="margin-left: 25px;">';

				    html = html + '<table  border=0 cellpadding=0 cellspacing=0 style="font: 8pt sans-serif, monospace;">';
				    html = html + '<tr><td colspan=2 align="center"><img src="/yii/cart/images/logo_print.png"></td></tr>';
				    html = html + '<tr><td colspan=2 align="center"><b>' + '* * * EL PATIO DE QUESIA * * *' + '</b></td></tr>';
				    html = html + '<tr><td colspan=2 align="center">' +
				    '-------------------------------------------------------' + '</td></tr>';
				    html = html + '<tr><td colspan=2 align="center">' + 'COMPROBANTE DE     PAGO' + '</td></tr>';
				    html = html + '<tr><td colspan=2 align="center">' +
				    '-------------------------------------------------------' + '</td></tr>';
				    html = html + '<tr><td colspan=2 align="center"><b>' +  result[0] + '</b></td></tr>';

				    var currentDate = new Date();
				    var day = currentDate.getDate();
				    var month = currentDate.getMonth() + 1;
				    var year = currentDate.getFullYear();
				    var hours = currentDate.getHours();
				    var minutes = currentDate.getMinutes();

				    if (minutes < 10) minutes = "0" + minutes

				    var suffix = "AM";
				    if (hours >= 12) {
				        suffix = "PM";
				        hours = hours - 12;
				    }
				    if (hours == 0) {
				        hours = 12;
				    }

				    html = html + '<tr><td align="left">' + 'Cantidad de Personas:' + '</td><td align="right">' + result[1] + '</td></tr>';
				    html = html + '<tr><td align="left">' + 'Fecha:' + '</td><td align="right">' + day + "/" + month + "/" + year + "<br/>" + hours + ":" + minutes + " " + suffix + '</td></tr>';

				    html = html + '<tr><td colspan=2 align="center">------------------------ DETALLES -----------------------</td></tr>';

				    for (i=0; i < platos.length; i++)
				        html = html + '<tr><td align="left"><b>' + platos[i][0] + '</b></td><td align="right" style="min-width: 80px;">' + platos[i][1] + ' x $' + platos[i][2] + '</td></tr>';						        

				    html = html + '<tr><td colspan=2 align="center">-------------------------------------------------------</td></tr>';
				    html = html + '<tr><td align="left">' + 'Importe:' + '</td><td align="right"><b>$' + result[2].toFixed(2) + '</b></td></tr>';

				    if (!isNaN($("#txtEfectivoMN").val()) || !isNaN($("#txtEfectivoCuc").val())) {
				        html = html + '<tr><td align="left">' + 'Pagado:' + '</td><td align="right">$' + parseFloat($("#txtEfectivoMN").val()).toFixed(2) + '</td></tr>';
				        html = html + '<tr><td align="left">' + 'Devuelto:' + '</td><td align="right">$' + parseFloat($("#txtVueltoMN").val()).toFixed(2) + '</td></tr>';
				    }
				    html = html + '<tr><td colspan=2 align="center">-------------------------------------------------------</td></tr>';
				    html = html + '<tr><td colspan=2 align="center">* * * Agradecemos su visita * * *</td></tr>';
				    html = html + '<tr><td colspan=2 align="center">-------------------------------------------------------</td></tr>';

				    html = html + '</table>';
				    html = html + '</div></body></html>';

				    var winprint = window.open('', 'print');
				    winprint.document.write(html);
				    winprint.print();winprint.close(); 
				}				
	  } });
   }
 });