<?php

/**
 * This is the model class for table "categoria_plato".
 *
 * The followings are the available columns in table 'categoria_plato':
 * @property integer $id
 * @property string $nombre
 * @property integer $es_cocina
 * @property integer $orden
 */
class CategoriaPlato extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return CategoriaPlato the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'categoria_plato';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('es_cocina', 'required'),
			array('es_cocina, orden', 'numerical', 'integerOnly'=>true),
			array('nombre', 'length', 'max'=>45),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, nombre, es_cocina, orden', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'platos' => array(self::HAS_MANY, 'Plato', 'categoria_plato_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'Id',
			'nombre' => 'Nombre',
			'es_cocina' => 'Es Cocina',
			'orden' => 'Orden',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);

		$criteria->compare('nombre',$this->nombre,true);

		$criteria->compare('es_cocina',$this->es_cocina);

		$criteria->compare('orden',$this->orden);

		return new CActiveDataProvider('CategoriaPlato', array(
			'criteria'=>$criteria,
		));
	}
}