<?php

/**
 * This is the model class for table "producto".
 *
 * The followings are the available columns in table 'producto':
 * @property integer $id
 * @property string $nombre
 * @property string $descripcion
 * @property string $precio_costo
 * @property string $precio_venta
 * @property integer $categoria_id
 * @property integer $unidad_medida_id
 */
class Producto extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @return Producto the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'producto';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('nombre', 'required'),
			array('categoria_id, unidad_medida_id', 'numerical', 'integerOnly'=>true),
			array('nombre', 'length', 'max'=>100),
			array('descripcion', 'length', 'max'=>254),
			array('precio_costo, precio_venta', 'length', 'max'=>7),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, nombre, descripcion, precio_costo, precio_venta, categoria_id, unidad_medida_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'existencia_invs' => array(self::HAS_MANY, 'ExistenciaInv', 'producto_id'),
			'ingredientes' => array(self::HAS_MANY, 'Ingrediente', 'producto_id'),
			'movimientos' => array(self::HAS_MANY, 'Movimiento', 'producto_id'),
			'categoria' => array(self::BELONGS_TO, 'Categoria', 'categoria_id'),
			'unidad_medida' => array(self::BELONGS_TO, 'UnidadMedida', 'unidad_medida_id'),
			'producto_descripcion' => array(self::HAS_ONE, 'ProductoDescripcion', 'id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'Id',
			'nombre' => 'Nombre',
			'descripcion' => 'Descripcion',
			'precio_costo' => 'Precio Costo',
			'precio_venta' => 'Precio Venta',
			'categoria_id' => 'Categoria',
			'unidad_medida_id' => 'Unidad Medida',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);

		$criteria->compare('nombre',$this->nombre,true);

		$criteria->compare('descripcion',$this->descripcion,true);

		$criteria->compare('precio_costo',$this->precio_costo,true);

		$criteria->compare('precio_venta',$this->precio_venta,true);

		$criteria->compare('categoria_id',$this->categoria_id);

		$criteria->compare('unidad_medida_id',$this->unidad_medida_id);

		return new CActiveDataProvider('Producto', array(
			'criteria'=>$criteria,
		));
	}
}