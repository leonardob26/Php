<?php

return array(
	/*
	'sample1'=>array(
		'nombre' => '',
		'descripcion' => '',
	),
	'sample2'=>array(
		'nombre' => '',
		'descripcion' => '',
	),
	*/
);
