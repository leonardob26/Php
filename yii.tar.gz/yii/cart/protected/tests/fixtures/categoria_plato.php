<?php

return array(
	/*
	'sample1'=>array(
		'nombre' => '',
		'es_cocina' => '',
		'orden' => '',
	),
	'sample2'=>array(
		'nombre' => '',
		'es_cocina' => '',
		'orden' => '',
	),
	*/
);
