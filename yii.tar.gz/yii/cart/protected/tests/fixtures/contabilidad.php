<?php

return array(
	/*
	'sample1'=>array(
		'cuenta_id' => '',
		'importe' => '',
		'movimiento_id' => '',
	),
	'sample2'=>array(
		'cuenta_id' => '',
		'importe' => '',
		'movimiento_id' => '',
	),
	*/
);
