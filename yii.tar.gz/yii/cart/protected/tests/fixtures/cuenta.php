<?php

return array(
	/*
	'sample1'=>array(
		'codigo' => '',
		'nombre' => '',
		'descripcion' => '',
	),
	'sample2'=>array(
		'codigo' => '',
		'nombre' => '',
		'descripcion' => '',
	),
	*/
);
