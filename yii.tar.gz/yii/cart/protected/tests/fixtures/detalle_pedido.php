<?php

return array(
	/*
	'sample1'=>array(
		'pedido_id' => '',
		'plato_id' => '',
		'cantidad' => '',
		'estado' => '',
		'fecha' => '',
	),
	'sample2'=>array(
		'pedido_id' => '',
		'plato_id' => '',
		'cantidad' => '',
		'estado' => '',
		'fecha' => '',
	),
	*/
);
