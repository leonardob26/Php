<?php

return array(
	/*
	'sample1'=>array(
		'plato_id' => '',
		'producto_id' => '',
		'cantidad' => '',
	),
	'sample2'=>array(
		'plato_id' => '',
		'producto_id' => '',
		'cantidad' => '',
	),
	*/
);
