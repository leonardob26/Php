<?php

return array(
	/*
	'sample1'=>array(
		'producto_id' => '',
		'proveedor_id' => '',
		'cantidad' => '',
		'precio' => '',
		'importe' => '',
	),
	'sample2'=>array(
		'producto_id' => '',
		'proveedor_id' => '',
		'cantidad' => '',
		'precio' => '',
		'importe' => '',
	),
	*/
);
