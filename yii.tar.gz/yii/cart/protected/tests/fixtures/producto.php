<?php

return array(
	/*
	'sample1'=>array(
		'nombre' => '',
		'descripcion' => '',
		'precio_costo' => '',
		'precio_venta' => '',
		'categoria_id' => '',
		'unidad_medida_id' => '',
	),
	'sample2'=>array(
		'nombre' => '',
		'descripcion' => '',
		'precio_costo' => '',
		'precio_venta' => '',
		'categoria_id' => '',
		'unidad_medida_id' => '',
	),
	*/
);
