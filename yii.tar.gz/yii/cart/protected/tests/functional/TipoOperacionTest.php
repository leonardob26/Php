<?php

class TipoOperacionTest extends WebTestCase
{
	public $fixtures=array(
		'tipoOperacions'=>'TipoOperacion',
	);

	public function testShow()
	{
		$this->open('?r=tipoOperacion/view&id=1');
	}

	public function testCreate()
	{
		$this->open('?r=tipoOperacion/create');
	}

	public function testUpdate()
	{
		$this->open('?r=tipoOperacion/update&id=1');
	}

	public function testDelete()
	{
		$this->open('?r=tipoOperacion/view&id=1');
	}

	public function testList()
	{
		$this->open('?r=tipoOperacion/index');
	}

	public function testAdmin()
	{
		$this->open('?r=tipoOperacion/admin');
	}
}
