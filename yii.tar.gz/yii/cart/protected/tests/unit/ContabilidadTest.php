<?php

class ContabilidadTest extends CDbTestCase
{
	public $fixtures=array(
		'contabilidads'=>'Contabilidad',
	);

	public function testCreate()
	{

	}
}