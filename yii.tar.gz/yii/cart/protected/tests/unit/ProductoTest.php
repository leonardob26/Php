<?php

class ProductoTest extends CDbTestCase
{
	public $fixtures=array(
		'productos'=>'Producto',
	);

	public function testCreate()
	{

	}
}