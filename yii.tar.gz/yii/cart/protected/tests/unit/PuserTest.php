<?php

class PuserTest extends CDbTestCase
{
	public $fixtures=array(
		'pusers'=>'Puser',
	);

	public function testCreate()
	{

	}
}