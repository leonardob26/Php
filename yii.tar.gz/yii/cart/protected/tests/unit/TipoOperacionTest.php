<?php

class TipoOperacionTest extends CDbTestCase
{
	public $fixtures=array(
		'tipoOperacions'=>'TipoOperacion',
	);

	public function testCreate()
	{

	}
}