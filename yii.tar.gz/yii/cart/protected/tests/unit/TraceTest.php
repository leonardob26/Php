<?php

class TraceTest extends CDbTestCase
{
	public $fixtures=array(
		'traces'=>'Trace',
	);

	public function testCreate()
	{

	}
}