<?php
$this->breadcrumbs=array(
	'Catalog',
);

$this->menu=array(
		array('label'=>'Unidades de medidas', 'url'=>array('/unidadMedida')),
		array('label'=>'Mesas', 'url'=>array('/mesa')),
		array('label'=>'Categoría del plato', 'url'=>array('/categoriaPlato')),
		array('label'=>'Platos', 'url'=>array('/plato')),
		array('label'=>'Categoria de Producto', 'url'=>array('/categoria')),
		array('label'=>'Producto', 'url'=>array('/producto')),
		array('label'=>'Cuentas contables', 'url'=>array('/cuenta')),
		array('label'=>'Proveedor de los productos', 'url'=>array('/proveedor')),
		array('label'=>'Usuarios', 'url'=>array('/puser')),
		array('label'=>'Trazas', 'url'=>array('/trace')),
		array('label'=>'Tipo de operaciones en las trazas', 'url'=>array('/tipoOperacion')),
);
?>

<h1>Catalogos</h1>
<p>En esta página podrá administrar los catálogos del sistema<p>