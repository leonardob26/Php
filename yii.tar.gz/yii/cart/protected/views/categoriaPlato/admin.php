<?php
$this->breadcrumbs=array(
	'Categoria Platos'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Create CategoriaPlato', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$.fn.yiiGridView.update('categoria-plato-grid', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Categoria Platos</h1>
<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'categoria-plato-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'nombre',
		'es_cocina',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
