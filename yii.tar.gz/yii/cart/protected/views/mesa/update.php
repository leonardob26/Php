<?php
$this->breadcrumbs=array(
	'Mesas'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Mesa', 'url'=>array('create')),
	array('label'=>'View Mesa', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Mesa', 'url'=>array('admin')),
);
?>

<h1>Update Mesa <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>