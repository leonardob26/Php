<?php $session=new CHttpSession; 
$session->open();
?>
<div data-role="page" class="jqm-demos ui-responsive-panel" id="page1" >
    <div data-role="content" style="padding: 0px;" >
    <div data-role="popup" id="popupPhoto" data-overlay-theme="a" data-theme="d" data-corners="false" style="width: 800px; height: 610px;">
		<a href="#" data-rel="back" data-role="button" data-theme="a" data-icon="delete" data-iconpos="notext" class="ui-btn-right">Cerrar</a>
		<img id="fotoPlato" class="popphoto" src="" alt="Imagen del plato" >
	</div>	
		<table width="100%" id="tblMesas">
			<tr>
				<?php echo $mesas; ?>
				<!--  <td><a href="#nav-panel" data-role="button" data-mini="true" data-inline="true" id="M1">Mesa1</a><div id="leg1" style="display: inline;">asd</div></td> -->
			</tr>
		</table>
		
		<div><div class="ui-bar ui-bar-b" >
			<table style="width: 100%">
				<tr>
					<td style="width: 30%;"><a id="btnAgregar" name="btnAgregar" href="#nav-panel" data-role="button" data-theme="e" 
								data-icon="plus" style="width: 300px;">Agregar plato</a></td>
					<td style="width: 30%;">
						<div id="divMesa" style="font-size: x-large; font-weight: bold; text-align: center;"><?php echo $nameMesaDefaul; ?></div>
					</td>
					<td style="width: 20%; text-align: right;">
						Personas en la mesa:  
					</td>
					<td style="width: 19%; padding-right: 14%"><input type="number" name="txtCantPersona" id="txtCantPersona"  value="<?php echo $cantPersona; ?>"  /></td>
				</tr>
			</table>
			<div id="divInsPlato" style="display: none;">
				<table style="width: 100%" >
				<tr>
					<td style="width: 50%; text-align: right; padding-right: 20px;"><div id="divPlato"></div>
					<input type="hidden" id="hidPlatoId"  /> <input type="hidden" id="hidDetalleId"  />
					</td>
					<td style="width: 4%; text-align: right;">
						<input type="number" id="txtCantidad"  value=""  />  
					</td>
					<td style="width: 15%; padding: 0 5px 0 5px;"><a id="btnAgregarPlato" href="#" data-role="button" data-theme="g" 
								data-icon="arrow-d" style="width: 100%;">Actualizar</a></td>
					<td style="width: 15%; padding: 0 5px 0 5px;"><a id="btnEliminarPlato" href="#" data-role="button" data-theme="f" 
								data-icon="delete" style="width: 100%;">Eliminar</a></td>
					<td  style="width: 15%; padding: 0 5px 0 5px;"><a id="btnCancelar" href="#" data-role="button" data-theme="c" 
								data-icon="back" style="width: 100%;">Cancelar</a></td>
				</tr>
				</table>
			</div>
		</div>		</div><!--/demo-html -->
		<div class="content-primary">
			<ul data-role="listview" data-divider-theme="c" id="lstPedidos" data-inset="true">
                   <?php echo $pedidos; ?> 
            </ul>
		</div>
	</div><!-- /content -->

    <div data-role="footer" data-position="fixed" data-theme="b" style="height: 40px">
    	<a href="#" data-role="button" id="btnEnviar" data-icon="check" style="margin-top:3px;" data-theme="b" class="<?php echo $classEnviarCocina; ?>">Enviar</a> 
		
		<div class="ui-btn-right" >
			<div data-role="fieldcontain" style="margin-top:0px;">
				<input type="text" id="txtPrecioTotal" size="12" value="$ <?php echo $total; ?>" data-theme="c" class="ui-disabled" style="text-align:right" />
			</div>
		</div>
    </div><!-- /footer -->

	<div data-role="panel"  data-theme="b" id="nav-panel" data-dismissible="false" data-position-fixed="true" data-animate="false">
		<!-- <a href="#" data-rel="close" data-role="button">Cerrar</a> -->
		<br/>
		<ul data-role="listview" data-theme="c" id="ulPlatos" class="nav-search" data-filter="true">
			<?php echo $platos; ?>
		</ul>

	</div><!-- /panel -->
    <div data-role="popup" id="popupEditar" data-overlay-theme="a" data-theme="c" data-dismissible="false" style="max-width:600px;" class="ui-corner-all">
	    <div data-role="header" data-theme="a" class="ui-corner-top">
	        <h1>Plato: </h1>
	    </div>
	    <div data-role="content" data-theme="d" class="ui-corner-bottom ui-content">
	        <form action="?r=movil/updateDetalle" method="post">
				<div data-role="fieldcontain">
				<table>
					<tr>
						<td align="right"><label for="selectmenu2">Cantidad:</label></td>
						<td align="right" width="70px"><input type="number" name="txtCantidad" id="txtCantidad" value="5"  /></td>
					</tr>
				</table>
                </div>
                <a href="#" data-theme="d" data-rel="back" data-inline="true" data-role="button">Cancelar</a>
                <button type="submit" id="btnOk" data-theme="b" data-inline="true" value="Ok">Aceptar</button>
                <button type="submit" id="btnEliminar" data-theme="b" data-inline="true" value="Eliminar">Eliminar</button>
			</form>
	        
	    </div>
	</div>
</div><!-- /page -->