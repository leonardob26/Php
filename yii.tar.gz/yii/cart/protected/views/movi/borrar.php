<?php $session=new CHttpSession; 
$session->open();
?>
<div data-role="page" class="jqm-demos ui-responsive-panel" id="page1" >
    <div data-role="content" style="padding: 1px;" >
    <ul data-role="listview" data-divider-theme="b" id="lstPedidos" data-inset="true">
		<?php echo $cad; ?>
		</ul>
				<!--  <td><a href="#nav-panel" data-role="button" data-mini="true" data-inline="true" id="M1">Mesa1</a><div id="leg1" style="display: inline;">asd</div></td> -->
	</div><!-- /content -->

    <div  data-role="footer" data-position="fixed" data-theme="b">
    	<a href="#" data-role="button" data-ajax="false" data-icon="check" data-theme="b">Enviar</a> 
		
		
    </div><!-- /footer -->


</div><!-- /page -->