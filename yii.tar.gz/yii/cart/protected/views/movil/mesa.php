<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/movil.css"  />
<script type="text/javascript">
window.setInterval(function() {
	$.ajax({ type: 'GET', url: "?r=movil/getRefresh", success: function(data){
			  if (data=="1") 
				  location.href='?r=movil';
		  } }); }, 10000);
</script>
<div data-role="page">
	<div data-role="content">
	<?php echo $cad; ?>
	</div>
</div>
