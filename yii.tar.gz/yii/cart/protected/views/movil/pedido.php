<?php $session=new CHttpSession; 
$session->open();
?>
<div data-role="page" class="type-interior">
	<!-- header -->
	<div data-role="header" data-theme="b" data-position="fixed">	
		<a href="?r=movil/mesa" data-ajax="false" data-icon="back">Atr&aacute;s</a>
		<h1><?php echo $session['mesaName']; ?></h1>
		
		<form action="#" method="get">
			<fieldset data-role="controlgroup" data-type="horizontal" data-mini="false" class="ui-btn-right" data-theme="c" style="top: 0px">
			<?php if ($session['mesaId']>0){
		    ?>
                <select name="cmbOcupado" id="cmbOcupado" data-theme="e" data-role="slider" style="width: 80px;">
                    <option value="off" <?php echo $ocupado==""?"selected='selected'":""; ?> >
                        Libre
                    </option>
                    <option value="on" <?php echo $ocupado!=""?"selected='selected'":""; ?>>
                        Ocupada
                    </option>
                </select>
                <?php }?>
		    </fieldset>
		</form>
		
		<div class="ui-bar ui-bar-b" >
		<div class="ui-grid-b">
			<div class="ui-block-a">
				<a id="btnAgregar" name="btnAgregar" <?php if ($session['mesaId']>0){ 
				  	  echo "class='" .  ($ocupado==""?'ui-disabled':'') . "'"; 
				  } ?> 
				  href="<?php echo '?r=movil/agregar&categoriaPlatoId=' . $categoriaPlatoId ; ?> "  
				  data-role="button" data-theme="e" data-icon="plus" data-ajax="false" style="width: 300px;">Agregar</a>
		 	</div>
		 	<div class="ui-block-b" style="text-align: right; margin: 15px 3px 0 10px;">
		     Personas: 
		    </div>
		    <div class="ui-block-c" style="width: 70px;" > 
		     	<input type="number" name="txtCantPersona" id="txtCantPersona"  value="<?php echo $cantPersona; ?>"  <?php echo "class='" .  ($ocupado==""?'ui-disabled':'') . "'"; ?>  />
		    </div> 
		</div>
		</div>
	</div><!-- /header -->

	<!-- content -->
	<div data-role="content">
		<div class="content-primary">
			<ul data-role="listview" data-divider-theme="b" data-inset="true">
                   <?php echo $cad; ?> 
                </ul>
		</div><!-- /content-primary -->
	</div><!-- /content -->
	
	<div data-role="footer" class="ui-bar" data-theme="b" data-position="fixed">
	 	<a href="?r=movil/cambiarEstadoPedido&pedidoId=<?php echo $session['pedidoId']; ?>&estado=Procesando" data-role="button" data-ajax="false" class="<?php echo $classEnviarCocina; ?>" data-icon="check" data-theme="b">Enviar</a> 
		
		<div class="ui-btn-right" style="margin-right:5px;margin-top:-5px;">
			<div data-role="fieldcontain" style="margin-top:5px;">
				<input type="text" name="txtPrecioTotal" id="txtPrecioTotal" size="12" value="$ <?php echo $total; ?>" data-theme="c" class="ui-disabled" style="text-align:right" />
			</div>
		</div>
		
	</div>

</div><!-- /page -->

