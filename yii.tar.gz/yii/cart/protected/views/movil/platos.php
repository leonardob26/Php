<?php 
$session=new CHttpSession;
$session->open();
?>
<div data-role="page" class="type-interior">
	<div data-role="header" data-theme="b" data-position="fixed">
		<a href="?r=movil/pedido&mesaId=<?php echo $session['mesaId']; ?>" data-icon="back" data-ajax="false">Atr&aacute;s</a>
		<h1>Listado de productos</h1>
	</div>
	<!-- content -->
	<div data-role="content">
		<div class="content-primary">
			<ul data-role="listview" data-split-theme="c" data-autodividers="true" data-filter="true">
			<?php echo $platosByCategoria ; ?>	
			</ul>							
		</div><!-- /content-primary -->
	</div>
	<div data-role="popup" id="popupPhoto" data-overlay-theme="a" data-theme="d" data-corners="false">
		<a href="#" data-rel="back" data-role="button" data-theme="a" data-icon="delete" data-iconpos="notext" class="ui-btn-right">Cerrar</a>
		<img id="fotoPlato" class="popphoto" src="" alt="Imagen del plato">
	</div>
	
	<div data-role="footer" class="btn-categoria-platos" data-id="tod" data-position="fixed">
		<div data-role="navbar"  data-grid="d">
		<ul>
		<?php foreach ($categorias as $categoria) {
			$class = $categoria->id==$categoriaPlatoId?' class="ui-btn-active  ui-state-persist"':' ';
			echo '<li><a href="?r=movil/agregar&categoriaPlatoId=' . $categoria->id . '"' . $class .  ' data-ajax="false">' . $categoria->nombre . '</a></li>';
		} ?>
		</ul>
		</div>
	</div>
</div>