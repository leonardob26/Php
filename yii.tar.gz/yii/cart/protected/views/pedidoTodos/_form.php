<?php
/* @var $this PedidosController */
/* @var $model Pedido */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'pedido-form',
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'mesa_id'); ?>
		<?php echo $form->dropDownList($model, 'mesa_id', CHtml::listData(Mesa::model()->findAll(array('order'=>'nombre')), 'id', 'nombre'));  ?>
		<?php echo $form->error($model,'mesa_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'fecha_pedido'); ?>
		<?php $this->widget('zii.widgets.jui.CJuiDatePicker', array(
				'name'=> 'Pedido[fecha_pedido]',
				    'value'=>$model->fecha_pedido,
				    // additional javascript options for the date picker plugin
				    'options'=>array(
				        'showAnim'=>'fold',
						'dateFormat'=>'yy-mm-dd',
				    ),
				    'htmlOptions'=>array(
				        'style'=>'height:20px;'
				    ),
				));?>
		<?php echo $form->error($model,'fecha_pedido'); ?>
		
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'importe_total'); ?>
		<?php echo $form->textField($model,'importe_total',array('size'=>7,'maxlength'=>7)); ?>
		<?php echo $form->error($model,'importe_total'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'estado'); ?>
		<?php echo $form->dropDownList($model, 'estado', Lookup::getEstadoPedido());  ?>
		<?php echo $form->error($model,'estado'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'propina'); ?>
		<?php echo $form->textField($model,'propina',array('size'=>7,'maxlength'=>7)); ?>
		<?php echo $form->error($model,'propina'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'pagado'); ?>
		<?php echo $form->textField($model,'pagado',array('size'=>7,'maxlength'=>7)); ?>
		<?php echo $form->error($model,'pagado'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'vuelto'); ?>
		<?php echo $form->textField($model,'vuelto',array('size'=>7,'maxlength'=>7)); ?>
		<?php echo $form->error($model,'vuelto'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'pagadocuc'); ?>
		<?php echo $form->textField($model,'pagadocuc',array('size'=>7,'maxlength'=>7)); ?>
		<?php echo $form->error($model,'pagadocuc'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->