 <script type="text/javascript">
var print = true;
var controller="Admin";
var change = true;
window.setInterval(function(){
	window.open("?r=pedidos/pedidosAdmin", "_self");
	 }, 10000);
</script>
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/app.css" />
 <input type="hidden" id="hidPedidoId" name="hidPedidoId" />
<div class="clearfix">
<div class="grid-view">
	<div class="opcionesGroup">
	    <?php echo $body; ?>
	</div>
</div>
</div>