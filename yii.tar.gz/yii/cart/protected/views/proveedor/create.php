<?php
/* @var $this ProveedorController */
/* @var $model Proveedor */

$this->breadcrumbs=array(
	'Proveedors'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'Manage Proveedor', 'url'=>array('admin')),
);
?>

<h1>Create Proveedor</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>