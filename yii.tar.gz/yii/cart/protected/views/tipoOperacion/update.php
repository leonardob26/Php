<?php
$this->breadcrumbs=array(
	'Tipo Operacions'=>array('admin'),
	'Update',
);

$this->menu=array(
	array('label'=>'Crear TipoOperacion', 'url'=>array('create')),
	array('label'=>'Lista Tipo Operacion', 'url'=>array('admin')),
);
?>

<h1>Update TipoOperacion <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>