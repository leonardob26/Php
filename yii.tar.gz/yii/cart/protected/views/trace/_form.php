<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'trace-form',
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'puser'); ?>
		<?php echo $form->textField($model,'puser',array('size'=>20,'maxlength'=>20)); ?>
		<?php echo $form->error($model,'puser'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'tipo_operacion_id'); ?>
		<?php echo $form->textField($model,'tipo_operacion_id'); ?>
		<?php echo $form->error($model,'tipo_operacion_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'plato_id'); ?>
		<?php echo $form->textField($model,'plato_id'); ?>
		<?php echo $form->error($model,'plato_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'cantidad'); ?>
		<?php echo $form->textField($model,'cantidad'); ?>
		<?php echo $form->error($model,'cantidad'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->