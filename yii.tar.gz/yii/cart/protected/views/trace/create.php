<?php
$this->breadcrumbs=array(
	'Trazas'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'Lista de trazas', 'url'=>array('admin')),
);
?>

<h1>Crear trazas</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>