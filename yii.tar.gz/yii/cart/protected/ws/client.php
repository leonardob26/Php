 <?php
    require_once("websocket.client.php");

    $input = '{"type":"message","data":"Hello world!!"}';
    $msg = WebSocketMessage::create($input);

    $client = new WebSocket("ws://192.168.147.28:12345/echo/");
    $client->open();
    $client->sendMessage($msg);

    // Wait for an incoming message
    $msg = $client->readMessage();

    $client->close();

    echo $msg->getData(); // Prints "Hello World!" when using the demo.php server
       ?>