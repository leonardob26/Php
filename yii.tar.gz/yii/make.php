<?php
/**
 * @Do Implementar lo de la los ingredientes y almacen
 * @Do Contabilidad
 */ 
class hacerAlgo {
	function function_name() {
		;
	}
}
?>